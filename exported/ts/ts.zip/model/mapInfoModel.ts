

export interface MapInfoModel {
    id: number,
    portalRequirements: number[]
}
