import { ComponentModel } from './componentModel';

export interface TalentRewardModel extends ComponentModel {

}
