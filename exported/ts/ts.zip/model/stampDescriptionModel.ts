

export interface StampDescriptionModel {
    descriptions: string[]
}
