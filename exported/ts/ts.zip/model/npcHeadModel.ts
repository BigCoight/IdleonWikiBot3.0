

export interface NpcHeadModel {
    location: string,
    world: string,
    noQuest: number,
    repeatable: string,
    type: string,
    birthWeight: number,
    starSign: string,
    mothersMaidenName: string,
    notes: string
}
