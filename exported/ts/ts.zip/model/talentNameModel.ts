

export interface TalentNameModel {
    name: string,
    id: number
}
