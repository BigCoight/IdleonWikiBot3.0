import { QuestType } from './questType';
import { NoteModel } from './noteModel';
import { ComponentModel } from './componentModel';
import { QuestModel } from './questModel';
import { CustomReqModel } from './customReqModel';

export interface CustomQuestModel extends QuestModel {
    CustomType: string,
    CustomArray: CustomReqModel[]
}
