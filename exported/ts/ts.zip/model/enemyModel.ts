import { EnemyDetailsModel } from './enemyDetailsModel';
import { BossDetailsModel } from './bossDetailsModel';
import { MapDataModel } from './mapDataModel';
import { EnemyNavModel } from './enemyNavModel';
import { EnemyTableModel } from './enemyTableModel';

export interface EnemyModel {
    details: EnemyDetailsModel,
    drops?: EnemyTableModel,
    mapData?: MapDataModel,
    navigation?: EnemyNavModel,
    bossData?: BossDetailsModel
}
