export enum BagType {
    Foods = "Foods",
    Chopping = "Chopping",
    bCraft = "bCraft",
    Critters = "Critters",
    Souls = "Souls",
    Bugs = "Bugs",
    Fishing = "Fishing",
    Mining = "Mining"
}
