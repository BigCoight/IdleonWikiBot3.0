

export interface ShrineModel {
    name: string,
    desc: string,
    baseBonus: number,
    increment: number,
    misc: number
}
