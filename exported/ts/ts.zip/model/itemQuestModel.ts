import { QuestType } from './questType';
import { NoteModel } from './noteModel';
import { ComponentModel } from './componentModel';
import { QuestModel } from './questModel';

export interface ItemQuestModel extends QuestModel {
    ItemReq: ComponentModel[]
}
