export enum EnemyType {
    monsterType = "monsterType",
    oreType = "oreType",
    treeType = "treeType",
    fishType = "fishType",
    bugType = "bugType"
}
