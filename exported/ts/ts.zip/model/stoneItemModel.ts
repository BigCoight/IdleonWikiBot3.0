import { DescItemModel } from './descItemModel';
import { TypeGen } from './typeGen';

export interface StoneItemModel extends DescItemModel {
    tier: string
}
