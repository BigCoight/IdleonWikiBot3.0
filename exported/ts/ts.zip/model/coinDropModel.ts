import { DropModel } from './dropModel';

export interface CoinDropModel extends DropModel {

}
