

export interface LiquidComponentModel {
    liquidNo: string,
    quantity: number
}
