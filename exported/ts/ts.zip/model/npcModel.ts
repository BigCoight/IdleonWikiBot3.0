import { NpcHeadModel } from './npcHeadModel';
import { QuestModel } from './questModel';
import { DialogueLineModel } from './dialogueLineModel';

export interface NpcModel {
    head?: NpcHeadModel,
    quests: Record<string, QuestModel>,
    dialogue: DialogueLineModel[]
}
