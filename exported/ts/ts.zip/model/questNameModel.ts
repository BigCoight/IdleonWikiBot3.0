

export interface QuestNameModel {
    name: string,
    difficulty: number
}
