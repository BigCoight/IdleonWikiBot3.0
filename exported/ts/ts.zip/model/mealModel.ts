

export interface MealModel {
    name: string,
    cookingReq: number,
    bonusQty: number,
    bonusText: string,
    description: string,
    bonusKey: string
}
