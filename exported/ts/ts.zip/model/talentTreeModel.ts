import { TalentModel } from './talentModel';

export interface TalentTreeModel {
    talents: Record<string, TalentModel>
}
