import { SubTableModel } from './subTableModel';

export interface SubTablesModel {
    sources: SubTableModel[]
}
