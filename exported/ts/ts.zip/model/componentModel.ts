

export interface ComponentModel {
    item: string,
    quantity: number
}
