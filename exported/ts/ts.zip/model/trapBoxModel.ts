import { TrapBoxTimeModel } from './trapBoxTimeModel';

export interface TrapBoxModel {
    times: TrapBoxTimeModel[]
}
