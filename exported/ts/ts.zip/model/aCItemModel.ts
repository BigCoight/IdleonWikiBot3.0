import { DescItemModel } from './descItemModel';
import { TypeGen } from './typeGen';

export interface ACItemModel extends DescItemModel {

}
