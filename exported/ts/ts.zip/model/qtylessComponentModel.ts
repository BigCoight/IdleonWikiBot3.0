

export interface QtylessComponentModel {
    item: string
}
