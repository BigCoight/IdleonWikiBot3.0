

export interface StatueDataModel {
    name: string,
    effect: string,
    dk: number,
    bonus: number
}
