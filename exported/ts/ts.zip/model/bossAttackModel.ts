

export interface BossAttackModel {
    name: string,
    damage: number
}
