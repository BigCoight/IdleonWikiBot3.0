

export interface LabBonusModel {
    no: number,
    x: number,
    y: number,
    range: number,
    bonusOn: number,
    bonusOff: number,
    name: string,
    description: string
}
