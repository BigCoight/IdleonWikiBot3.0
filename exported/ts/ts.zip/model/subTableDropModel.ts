import { DropModel } from './dropModel';

export interface SubTableDropModel extends DropModel {

}
