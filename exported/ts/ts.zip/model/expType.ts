export enum ExpType {
    Class = "Class",
    Mining = "Mining",
    Smithing = "Smithing",
    Choppin = "Choppin",
    Fishing = "Fishing",
    Alchemy = "Alchemy",
    Catching = "Catching",
    Trapping = "Trapping",
    Construction = "Construction",
    Worship = "Worship"
}
