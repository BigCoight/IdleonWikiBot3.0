

export interface PartModel {
    item: string,
    base: number,
    increment: number
}
