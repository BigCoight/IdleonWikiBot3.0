import { VendorModel } from './vendorModel';

export interface ItemVendorsModel {
    vendors: VendorModel[]
}
