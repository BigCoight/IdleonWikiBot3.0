

export interface DungTraitModel {
    name: string
}
