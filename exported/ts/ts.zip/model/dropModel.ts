

export interface DropModel {
    item: string,
    quantity: number,
    chance: number,
    questLink: string
}
