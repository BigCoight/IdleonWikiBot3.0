import { SourceModel } from './sourceModel';

export interface SourcesModel {
    sources?: SourceModel[],
    recipeFrom?: SourceModel[],
    questAss?: SourceModel[]
}
