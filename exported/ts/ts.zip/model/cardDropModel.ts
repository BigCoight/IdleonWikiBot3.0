import { DropModel } from './dropModel';

export interface CardDropModel extends DropModel {

}
