import { TaskUnlockModel } from './taskUnlockModel';

export interface TaskUnlocksModel {
    unlocks: TaskUnlockModel[][]
}
