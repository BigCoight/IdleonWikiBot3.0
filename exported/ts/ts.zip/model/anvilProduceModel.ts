

export interface AnvilProduceModel {
    item: string,
    no: number,
    time: number,
    levelReq: number,
    exp: number
}
