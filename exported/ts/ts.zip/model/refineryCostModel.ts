import { ComponentModel } from './componentModel';

export interface RefineryCostModel {
    cost: ComponentModel[]
}
