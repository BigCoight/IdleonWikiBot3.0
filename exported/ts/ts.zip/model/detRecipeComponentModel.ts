

export interface DetRecipeComponentModel {
    indent: number,
    item: string,
    quantity: number
}
