

export interface SaltLickModel {
    item: string,
    desc: string,
    baseCost: number,
    increment: number,
    baseBonus: number,
    maxLevel: number
}
