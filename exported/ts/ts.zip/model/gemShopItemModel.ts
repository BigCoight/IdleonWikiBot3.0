

export interface GemShopItemModel {
    name: string,
    itemName: string,
    desc: string,
    cost: number,
    no: number,
    maxPurchases: number,
    qty: number,
    costIncrement: number
}
