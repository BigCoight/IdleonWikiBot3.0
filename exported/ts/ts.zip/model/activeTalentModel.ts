

export interface ActiveTalentModel {
    name: string,
    K: number,
    D: number,
    s: number,
    cooldown: number,
    castTime: number,
    manaCost: number,
    inputReq: number,
    AFKrange: number,
    AFKtype: string,
    AFKactivity: number
}
