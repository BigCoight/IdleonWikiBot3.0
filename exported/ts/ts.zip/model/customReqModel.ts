

export interface CustomReqModel {
    desc: string,
    finalV: number,
    type: string,
    startV: number
}
