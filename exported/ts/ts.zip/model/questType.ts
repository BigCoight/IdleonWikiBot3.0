export enum QuestType {
    NoQuest = "NoQuest",
    Custom = "Custom",
    ItemsAndSpaceRequired = "ItemsAndSpaceRequired",
    LevelReq = "LevelReq",
    SpaceRequired = "SpaceRequired"
}
