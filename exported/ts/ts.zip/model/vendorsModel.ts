import { VendorModel } from './vendorModel';

export interface VendorsModel {
    items: VendorModel[]
}
