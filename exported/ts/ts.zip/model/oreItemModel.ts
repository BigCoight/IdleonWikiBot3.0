import { DescItemModel } from './descItemModel';
import { TypeGen } from './typeGen';

export interface OreItemModel extends DescItemModel {

}
