import { TerritoryEnemyModel } from './territoryEnemyModel';

export interface InfiniteTerritoryModel {
    enemies: TerritoryEnemyModel[]
}
