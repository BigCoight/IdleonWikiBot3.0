

export interface CritterModel {
    location: string,
    baseExp: number,
    baseShinyRate: number,
    shiny: string,
    effForBonus: number
}
