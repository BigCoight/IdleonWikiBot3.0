

export interface TerritoryEnemyModel {
    id: string,
    health: number,
    colour: number,
    size: number
}
