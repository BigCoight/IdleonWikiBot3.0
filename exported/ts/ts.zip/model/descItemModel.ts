import { BaseItemModel } from './baseItemModel';
import { TypeGen } from './typeGen';

export interface DescItemModel extends BaseItemModel {
    description: string
}
