

export interface TaskUnlockModel {
    item: string,
    tabNo: number,
    recipNo: number
}
