

export interface ArenaBonusModel {
    desc: string
}
