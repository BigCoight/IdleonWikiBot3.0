import { NoteModel } from './noteModel';

export interface NpcNoteModel {
    notes: Record<string, NoteModel>
}
