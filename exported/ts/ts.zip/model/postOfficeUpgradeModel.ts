

export interface PostOfficeUpgradeModel {
    bonus: string,
    x1: number,
    x2: number,
    func: string
}
