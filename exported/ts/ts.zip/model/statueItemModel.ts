import { StatueDataModel } from './statueDataModel';
import { BonusItemModel } from './bonusItemModel';
import { TypeGen } from './typeGen';

export interface StatueItemModel extends BonusItemModel {
    statueData: StatueDataModel
}
