

export interface SourceModel {
    wikiName: string,
    txtName: string
}
