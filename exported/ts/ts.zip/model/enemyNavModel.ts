

export interface EnemyNavModel {
    prev?: string,
    next?: string,
    hasCrystal?: boolean,
    crystalName?: string,
    hasCard?: boolean
}
