import { ComponentModel } from './componentModel';

export interface ExpRewardModel extends ComponentModel {

}
