export enum AbilityType {
    Red = "Red",
    Green = "Green",
    Special = "Special",
    Unsure = "Unsure"
}
