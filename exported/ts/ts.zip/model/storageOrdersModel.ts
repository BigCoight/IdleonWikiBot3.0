import { StorageOrderModel } from './storageOrderModel';

export interface StorageOrdersModel {
    order: StorageOrderModel[]
}
