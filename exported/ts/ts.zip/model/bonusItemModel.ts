import { DescItemModel } from './descItemModel';
import { TypeGen } from './typeGen';

export interface BonusItemModel extends DescItemModel {
    bonus: string
}
