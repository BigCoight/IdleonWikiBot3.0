

export interface FishingToolkitModel {
    name: string,
    depth1: number,
    depth2: number,
    depth3: number,
    depth4: number,
    fishingExp: number,
    fishingSpeed: number,
    fishingPower: number
}
