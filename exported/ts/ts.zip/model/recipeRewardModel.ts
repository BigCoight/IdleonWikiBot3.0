import { ComponentModel } from './componentModel';

export interface RecipeRewardModel extends ComponentModel {

}
