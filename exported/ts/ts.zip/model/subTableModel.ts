

export interface SubTableModel {
    name: string,
    chance: number,
    quantity: number
}
