

export interface MapNameModel {
    name: string,
    id: number
}
