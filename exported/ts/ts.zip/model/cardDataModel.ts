

export interface CardDataModel {
    cardID: string,
    category: string,
    perTier: number,
    effect: string,
    bonus: number,
    order: number
}
