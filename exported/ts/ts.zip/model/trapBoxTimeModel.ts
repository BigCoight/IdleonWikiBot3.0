

export interface TrapBoxTimeModel {
    time: number,
    qtyX: number,
    expX: number,
    shinyX: number
}
