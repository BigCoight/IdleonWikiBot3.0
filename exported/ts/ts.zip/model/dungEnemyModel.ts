

export interface DungEnemyModel {
    intName: string,
    health: number,
    damage: number,
    credit1DR: number,
    credit2DR: number,
    cardVal: number,
    coins: number,
    itemDropChance: number,
    cardDropChance: number
}
