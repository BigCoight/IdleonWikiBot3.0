

export interface CollectionModelModel {

}
