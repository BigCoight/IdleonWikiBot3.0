

export interface MiscUpgradeModel {
    upgrade: string,
    min: number,
    max: number
}
