

export interface StorageOrderModel {
    order: number,
    obtainable: boolean,
    bag: string
}
