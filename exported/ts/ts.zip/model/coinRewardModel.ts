import { ComponentModel } from './componentModel';

export interface CoinRewardModel extends ComponentModel {

}
