import { DropModel } from './dropModel';

export interface ItemDropModel extends DropModel {

}
