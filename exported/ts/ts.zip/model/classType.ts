export enum ClassType {
    All = "All",
    Mage = "Mage",
    Warrior = "Warrior",
    Beginner = "Beginner",
    Archer = "Archer"
}
