

export interface TaskDescriptionModel {
    name: string,
    description: string,
    extraStr: string,
    number1: number,
    descLine2: string,
    numbers: number[]
}
