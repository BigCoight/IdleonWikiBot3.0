import { DropModel } from './dropModel';

export interface TalentDropModel extends DropModel {

}
