

export interface DungPassiveModel {
    effect: string,
    x1: number,
    x2: number,
    func: string,
    type: string,
    lvlUpText: string
}
