import { DescItemModel } from './descItemModel';
import { TypeGen } from './typeGen';

export interface CarryBagItemModel extends DescItemModel {
    level: number
}
