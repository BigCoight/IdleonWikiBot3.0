import { DetDropModel } from './detDropModel';

export interface DetDropsModel {
    sources: DetDropModel[]
}
