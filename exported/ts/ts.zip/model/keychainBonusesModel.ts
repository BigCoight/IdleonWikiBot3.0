import { KeychainBonusModel } from './keychainBonusModel';

export interface KeychainBonusesModel {
    bonuses: KeychainBonusModel[]
}
