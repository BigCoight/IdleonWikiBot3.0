

export interface GoldenFoodDataModel {
    effect: string,
    amount: number
}
