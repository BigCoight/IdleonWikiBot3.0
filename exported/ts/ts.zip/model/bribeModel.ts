

export interface BribeModel {
    name: string,
    desc: string,
    cost: number,
    type: string,
    intName: string,
    amount: number
}
