import { DropModel } from './dropModel';

export interface RecipeDropModel extends DropModel {

}
