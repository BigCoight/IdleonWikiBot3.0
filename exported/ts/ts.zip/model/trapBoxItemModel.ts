import { ClassType } from './classType';
import { TrapBoxModel } from './trapBoxModel';
import { ToolItemModel } from './toolItemModel';
import { TypeGen } from './typeGen';

export interface TrapBoxItemModel extends ToolItemModel {
    trapBoxData: TrapBoxModel
}
