

export interface CardSetModel {
    bonus: string,
    scaling: number,
    image: string
}
