import { MiscUpgradeModel } from './miscUpgradeModel';

export interface DungEnhanceModel {
    enhancements: MiscUpgradeModel[]
}
