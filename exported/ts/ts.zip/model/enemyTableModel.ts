import { DropModel } from './dropModel';

export interface EnemyTableModel {
    drops: DropModel[]
}
