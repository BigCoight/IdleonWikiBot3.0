import { DropModel } from './dropModel';

export interface DropTableModel {
    drops: DropModel[],
    subTable: string
}
