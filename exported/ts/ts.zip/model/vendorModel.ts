

export interface VendorModel {
    vendor: string,
    item: string,
    quantity: number,
    no: number,
    purchasePrice: number
}
