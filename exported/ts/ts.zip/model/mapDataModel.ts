

export interface MapDataModel {
    area: string,
    world: string,
    id: number,
    portalRequirements: number[]
}
