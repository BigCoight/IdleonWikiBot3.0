import { DungPassiveModel } from './dungPassiveModel';

export interface DungPassivesModel {
    passives: DungPassiveModel[]
}
