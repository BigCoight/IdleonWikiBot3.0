

export interface CardDropChanceModel {
    dropChance: number
}
