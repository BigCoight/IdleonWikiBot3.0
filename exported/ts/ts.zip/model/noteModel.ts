

export interface NoteModel {
    note: string
}
