

export interface AchievementModel {
    name: string,
    qty: number,
    desc: string,
    rewards: string,
    world: string
}
