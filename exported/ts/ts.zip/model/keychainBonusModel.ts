

export interface KeychainBonusModel {
    bonus: string,
    lvl1: number,
    lvl2: number,
    lvl3: number
}
