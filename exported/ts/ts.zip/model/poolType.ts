export enum PoolType {
    FishSmall = "FishSmall",
    FishMed = "FishMed"
}
