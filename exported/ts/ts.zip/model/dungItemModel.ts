

export interface DungItemModel {
    name: string,
    bonus: string,
    increment: number,
    rarity: string,
    desc: string,
    lvlText: string,
    baseValue: number,
    maxLevel: number,
    achieve: string,
    world: string
}
