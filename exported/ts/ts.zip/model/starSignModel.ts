

export interface StarSignModel {
    name: string,
    text: string,
    x: number,
    y: number,
    prevReq: number,
    cost: number
}
