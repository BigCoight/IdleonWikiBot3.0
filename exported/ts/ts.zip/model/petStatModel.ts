

export interface PetStatModel {
    petId: string,
    x1: number,
    x2: number,
    x3: number,
    x4: number,
    unlockOrder: number,
    world: number
}
