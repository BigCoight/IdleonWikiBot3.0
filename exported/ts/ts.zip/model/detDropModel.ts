

export interface DetDropModel {
    source: string,
    quantity: number,
    chance: number
}
