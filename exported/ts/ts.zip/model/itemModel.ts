import { RecipeModel } from './recipeModel';
import { NoteModel } from './noteModel';
import { AnvilProduceModel } from './anvilProduceModel';
import { BaseItemModel } from './baseItemModel';
import { ItemVendorsModel } from './itemVendorsModel';
import { SourcesModel } from './sourcesModel';
import { DetDropsModel } from './detDropsModel';

export interface ItemModel {
    item: BaseItemModel,
    sources?: SourcesModel,
    notes?: NoteModel,
    recipe?: RecipeModel,
    vendors?: ItemVendorsModel,
    anvilProduction?: AnvilProduceModel,
    detDrops?: DetDropsModel
}
