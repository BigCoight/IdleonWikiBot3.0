

export interface FlurboShopModel {
    intId: string,
    cost: number,
    noPurchases: number,
    displayName: string,
    description: string
}
